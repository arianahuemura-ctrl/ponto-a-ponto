# Fontes da revisão técnico-científica PaP — 2/11/2026

Extraia em diretório novo. Não sobreponha o repositório ou uma entrega anterior.
Entre em `relatorio/` e compile:

    latexmk -norc -lualatex -interaction=nonstopmode -halt-on-error -outdir=build relatorio_final_pi2_v2.tex

Requer TeX Live com abntex2, memoir, TikZ e os pacotes indicados no preâmbulo; Times New Roman instalada. Não precisa iniciar o aplicativo ou abrir bancos. São incluídos os 27 fontes ativos, imagens, gráficos vetoriais e PDF confirmado necessários, mais documentação de revisão e insumos geográficos. A pasta `imgs/` é materializada no pacote para não depender do symlink do repositório. Manifesto SHA-256 em `MANIFESTO.json`.

A auditoria completa e os registros históricos permanecem no repositório; este pacote não duplica todos os artefatos mencionados na narrativa. O CSV original do benchmark é externo ao pacote: caminho e hash em `revisao-tecnico-cientifica-2026-11-02/metricas-recalculadas.json`. Os gráficos já estão prontos para compilar. Para regenerá-los a partir desse CSV, com Python, NumPy e Matplotlib:

    python3 revisao-tecnico-cientifica-2026-11-02/generate_figures.py --benchmark-csv /caminho/paired-results.csv --output-dir /diretorio/novo

O script usa a malha e as coordenadas da auditoria incluídas, sem criar experimentos. Mapas e estatísticas não são novas observações de campo. O parecer confirmado não foi alterado. O vídeo da capa ainda é provisório. Consulte ALTERACOES.md e VALIDACAO.md para alcance e pendências.
